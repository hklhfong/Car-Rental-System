from django.apps import AppConfig


class RentalCarConfig(AppConfig):
    name = 'rental_car'
