from django.contrib import admin
from django.urls import path, re_path

from rental_car import views as rental_car
from signup import views as signup

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', rental_car.index),
    path('index2/', rental_car.index2),
    path('index3/', signup.index3),
    path('post1/', rental_car.post1),
    path('clientpost1/', rental_car.clientpost1),
    path('post3/', signup.post3),
    path('sindex/', rental_car.sindex),
    ##path ('insert/', rental_car.insert),
    ##re_path (r'search/(\d+)/$' , rental_car.query),

    re_path (r'sdelete/(\d+)/$', signup.sdelete),
    re_path (r'cdelete/(\d+)/$', rental_car.cdelete),
    re_path(r'delete/(\d+)/$', rental_car.delete),




    re_path (r'clientedit/(\d+)/$', rental_car.clientedit),
    re_path (r'clientedit/(\d+)/(\w+)$', rental_car.clientedit),

    re_path (r'sedit/(\d+)/$', signup.sedit),
    re_path (r'sedit/(\d+)/(\w+)$', signup.sedit),

    re_path(r'edit/(\d+)/$', rental_car.edit),
    re_path(r'edit/(\d+)/(\w+)$',rental_car.edit),






    path('customer_sign_in/', signup.customer_sign_in),
    path('customer_sign_up/', signup.signup),
    path('staff_sign_in/', signup.staff_sign_in),
    path('staff_main_page/', signup.staff_main_page),
    path('signout/', signup.signout),
    path('staff_signout/', signup.staff_signout),
    path('home/', signup.home),


]